var express = require('express');
var router = express.Router();
var path = require('path');
var clientDir = path.join(__dirname, 'client')

/* GET home page. */
router.get('/', function(req, res) {
  res.sendfile('client/view/index.html');
});

module.exports = router;
