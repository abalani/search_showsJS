var express = require('express');
var superagent = require('superagent');

var router = express.Router();

/* GET show listing. */
router.get('/search', function(req, res) {
  superagent
   .get('http://api.tvmaze.com/search/shows?q='+req.query.q)
   .end(function(err, apiRes){
      res.json(apiRes); 
   });
});

/* GET show details by showID. */
router.get('/show/:showID', function(req, res) {
  var showID = req.params.showID;
  superagent
   .get('http://api.tvmaze.com/shows/'+showID + "?embed=cast")
   .end(function(err, apiRes){
      res.json(apiRes); 
   });
});

module.exports = router;
