var FIREBASE_URL = "https://tvmaze1.firebaseio.com/";

var ID = function() {
  // Math.random should be unique because of its seeding algorithm.
  // Convert it to base 36 (numbers + letters), and grab the first 9 characters
  // after the decimal.
  return '_' + Math.random().toString(36).substr(2, 9);
};

var getAppID = function() {
  var tvSearchId = localStorage.getItem('tvSearchId');
  if (tvSearchId == "undefined" || tvSearchId == null) {
    tvSearchId = ID();
    localStorage.setItem('tvSearchId', tvSearchId);
  }
  return tvSearchId;
}


var app = angular.module('myApp', ['ngResource', 'ngRoute', 'firebase', 'ui.bootstrap']);

app.filter('inSlicesOf', ['$rootScope',
  function($rootScope) {
    makeSlices = function(items, count) {
      if (!count)
        count = 3;

      if (!angular.isArray(items) && !angular.isString(items)) return items;

      var array = [];
      for (var i = 0; i < items.length; i++) {
        var chunkIndex = parseInt(i / count, 10);
        var isFirst = (i % count === 0);
        if (isFirst)
          array[chunkIndex] = [];
        array[chunkIndex].push(items[i]);
      }

      if (angular.equals($rootScope.arrayinSliceOf, array))
        return $rootScope.arrayinSliceOf;
      else
        $rootScope.arrayinSliceOf = array;

      return array;
    };

    return makeSlices;
  }
]);

app.directive('showTv', function() {
  return {
    restrict: 'AE',
    replace: 'false',
    templateUrl: 'view/show-templete.html'
  };
});

app.config(
  function($routeProvider) {
    $routeProvider.
    when('/', {
        templateUrl: 'view/show-search.html',
        activetab: 'show'
      })
      .when('/show/:showID', {
        controller: 'ShowDetailCtrl',
        templateUrl: 'view/show.html',
        activetab: 'show'
      })
      .when('/search-history', {
        controller: 'SearchHistoryCtrl',
        templateUrl: 'view/search-history.html',
        activetab: 'search-history'
      })
      .when('/history-view/:searchParam', {
        templateUrl: 'view/history-view.html',
        activetab: 'search-history'
      })
      .otherwise({
        redirectTo: '/'
      });
  }
);

app.factory('RestFactory', function($resource) {
  return $resource("api/search");
});

app.factory('ShowFactory', function($resource) {
  return $resource("/api/show/:showID");
});

app.service('SearchService', function(ShowFactory, RestFactory) {

  var visitors;

  var registerVisitor = function(visitor) {
    visitors = visitor;
  }

  var notifyAll = function() {
    visitors.visit();
  }

  var searchResult;

  var addSearchItem = function(searchParam) {
    console.log("searchParam>> " + searchParam);
    RestFactory.get({
      q: searchParam
    }, function(searchResponse) {
      if (!searchResponse.text) {
        searchResult = {
          "_error": "No data found"
        }
      } else {
        searchResult = JSON.parse(searchResponse.text);
        console.log("searchResult>> " + searchResult);
      }
      notifyAll();
    });
  }

  var getSearchResult = function() {
    var _searchResult = searchResult;
    searchResult = {
      "_error": "No data found"
    };
    return _searchResult;
  }

  var getShowDetailByID = function(showID, callBack) {
    ShowFactory.get({
      'showID': showID
    }, function(searchResponse) {
      callBack(JSON.parse(searchResponse.text));
    });
  }

  return {
    registerVisitor: registerVisitor,
    addSearchItem: addSearchItem,
    getSearchResult: getSearchResult,
    getShowDetailByID: getShowDetailByID
  };
});


var DAFAULT_IMAGE = "image/default.png";

function isNull(obj) {
  if (obj === undefined || obj === null) {
    return true;
  }
  return false;
}

app.controller("ShowDetailCtrl", function($scope, SearchService, $routeParams) {

  $scope.showID = $routeParams.showID;

  SearchService.getShowDetailByID($scope.showID, function(responseJSON) {
    console.log("Haila!!");
    console.log(responseJSON);
    $scope.name = responseJSON.name;
    $scope.image = responseJSON.image.medium;
    $scope.summary = responseJSON.summary.replace(/<\/?[^>]+(>|$)/g, "");;
    $scope.genres = responseJSON.genres;
    $scope.casts = [];
    for (var item in responseJSON._embedded.cast) {
      var cast = {}
      console.log(item);
      cast['name'] = responseJSON._embedded.cast[item].person.name;
      cast['characterName'] = responseJSON._embedded.cast[item].character.name;
      if (isNull(responseJSON._embedded.cast[item].character.image)) {
        if (isNull(responseJSON._embedded.cast[item].person.image)) {
          cast['image'] = DAFAULT_IMAGE;
        } else {
          cast['image'] = responseJSON._embedded.cast[item].person.image.medium;
        }
      } else {
        cast['image'] = responseJSON._embedded.cast[item].character.image.medium;
      }
      $scope.casts.push(cast);
    }
  });

});


app.controller("SearchCtrl", function($scope, SearchService, $firebaseArray, $http) {

  $scope.searchHistory = $firebaseArray(new Firebase(FIREBASE_URL + getAppID()));

  $scope.onSelect = function($item, $model, $label) {
    SearchService.addSearchItem($model);
  };

  $scope.search = function() {
    SearchService.addSearchItem($scope.selected);
    $scope.searchHistory.$add({
      text: $scope.selected
    });
  };

});


app.controller("SearchResultCtrl", function($scope, SearchService, $location, $routeParams) {

  $scope.searchTerm = $routeParams.searchParam;
  if ($scope.searchTerm == null) {
    $scope.searchTerm = "girls";
  }
  SearchService.registerVisitor(this);
  SearchService.addSearchItem($scope.searchTerm);
  SearchService.getSearchResult();

  $scope.showDetail = function(showID) {
    $location.path("/show/" + showID);
  };




  this.visit = function() {
    console.log("searchResult-1>>");

    $scope.searchResultList = [];
    var searchResult = SearchService.getSearchResult();
    if (searchResult['_error']) {
      $scope.error = $scope.searchResult['_error'];
    } else {
      for (var item in searchResult) {
        var _searchResult = {}
        _searchResult['id'] = searchResult[item].show.id;
        _searchResult['name'] = searchResult[item].show.name;
        _searchResult['summary'] = searchResult[item].show.summary.replace(/<\/?[^>]+(>|$)/g, "");


        if (isNull(searchResult[item].show.image)) {
          _searchResult['mediumImage'] = DAFAULT_IMAGE;
        } else {
          _searchResult['mediumImage'] = searchResult[item].show.image.medium;
        }

        $scope.searchResultList.push(_searchResult);
      }
    }
    console.log($scope.searchResultList);

  };


});

app.controller("SearchHistoryCtrl", function($scope, $firebaseArray, SearchService, $location) {
  var ref = new Firebase(FIREBASE_URL + getAppID());
  $scope.history = $firebaseArray(ref);
  $scope.search = function(searchTerm) {
    console.log(searchTerm);
    $location.path('/history-view/' + searchTerm);
  };
});

app.controller("MenuCntrl", function($scope, $route) {
  $scope.$route = $route;
});
